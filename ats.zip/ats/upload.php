<?php
include "connection.php";
require_once "controllerUserData.php";
require_once "checklogin.php";

$tablename = $_SESSION['tablename'];

if(isset($_POST["file"])){
  $fileName = $_FILES["file"]["name"];
  $fileExtension = explode('.', $fileName);
  $fileExtension = strtolower(end($fileExtension));
  $newFileName = date("Y.m.d") . " - " . date("h.i.sa") . "." . $fileExtension;

  $targetDirectory = "uploads/" . $newFileName;
  move_uploaded_file($_FILES['file']['tmp_name'], $targetDirectory);

  error_reporting(0);
  ini_set('display_errors', 0);

  require 'excelReader/excel_reader2.php';
  require 'excelReader/SpreadsheetReader.php';

  $reader = new SpreadsheetReader($targetDirectory);
  foreach($reader as $key => $row){
    $first_name = $row[1];
    $last_name = $row[1];
    $email = $row[2];
    $linkedin = $row[3];
    $tags = $row[4];
  
    mysqli_query($con, "INSERT INTO $tablename (id, first_name, last_name, email, linkedin, tags, image_url) VALUES (NULL, '$first_name', '$last_name', '$email', '$linkedin', '$tags', '')");

  }

  if (mysqli_error($con)) {
    echo '<script>alert("Error: ' . mysqli_error($con) . '")</script>';
 }
 header("Location: importcsv.php");
  exit();
}


  
?>