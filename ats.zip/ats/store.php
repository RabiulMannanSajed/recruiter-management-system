<?php
header('Access-Control-Allow-Origin: chrome-extension://japdpcegmahlgdkbegebbpfhaalhakkg');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include "connection.php";

$data = file_get_contents('php://input');
$data = json_decode($data, true); // decode JSON data
$name = isset($data['name']) ? mysqli_real_escape_string($con, $data['name']) : '';
$title = isset($data['title']) ? mysqli_real_escape_string($con, $data['title']) : '';
$location = isset($data['location']) ? mysqli_real_escape_string($con, $data['location']) : '';
$image_url = isset($data['image_url']) ? mysqli_real_escape_string($con, $data['image_url']) : '';
$linkedin = isset($data['url']) ? mysqli_real_escape_string($con, $data['url']) : '';

// Split the name into an array using the space character as the delimiter
$nameArr = explode(' ', $name);
$first_name = isset($nameArr[0]) ? mysqli_real_escape_string($con, $nameArr[0]) : '';
$last_name = isset($nameArr[1]) ? mysqli_real_escape_string($con, $nameArr[1]) : '';

// Store data in database
if (!empty($first_name) || !empty($last_name) || !empty($title) || !empty($location) || !empty($image_url) || !empty($linkedin)) {
    $query = "INSERT INTO Sheikh__Saadi__candidates_all (first_name, last_name, title, location, image_url,linkedin) VALUES ('$first_name', '$last_name', '$title', '$location', '$image_url', '$linkedin')";
    if (!mysqli_query($con, $query)) {
        die('Error storing data: ' . mysqli_error($con));
    }
    echo 'Data stored successfully';
} else {
    echo 'No data provided';
}

// Close database connection
mysqli_close($con);
?>