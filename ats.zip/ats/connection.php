<?php 
$con = mysqli_connect('localhost', 'u576206221_FfnqZ', 'p&4nCNa8739T', 'u576206221_AQsbB');

?>